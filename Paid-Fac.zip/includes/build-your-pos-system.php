<section id="build-your-pos-section" class="build-your-pos">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="build-your-pos-text-area text-center" data-aos="zoom-in" data-aos-duration="1500">
                    <h2 class="banner-title">Elevate your business, <br> build your POS system today!</h2>
                    <div class="both-cta-area mt-30px">
                        <a class="primary-btn btn-2 bg-white" href="#">
                            Get started
                        </a>
                        <a class="primary-btn btn-2 text-white bg-transparent" href="#">
                            Contact sales
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>